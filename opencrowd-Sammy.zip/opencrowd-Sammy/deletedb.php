<?php
unlink('/home/ubuntu/workspace/databases/lettucebuy.db');
?>